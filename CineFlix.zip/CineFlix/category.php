<?php
include_once('includes/config.php');

include_once('includes/function.php');

$category_name = $_GET['category'];

$id = get_caregory_id($conn,$category_name);


$sql = "SELECT * FROM main_card WHERE category_id = $id ORDER BY id DESC";
$run_sql = mysqli_query($conn,$sql);


  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>HTML</title>
  
  <!-- HTML -->
  
  <link rel="stylesheet" href="./assets/css/main.css">

  <link rel="stylesheet" href="./assets/css/media_query.css">


  <!--
    - google font link
  -->
  <link href="https://fonts.googleapis.com/css?family=Inter:100,200,300,regular,500,600,700,800,900" rel="stylesheet" />
  <!-- Custom Styles -->
  <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="container">
    
  
    <header class="">



      <div class="navbar">


        <!--
          - menu button for small screen
        -->
        <button class="navbar-menu-btn">
          <span class="one"></span>
          <span class="two"></span>
          <span class="three"></span>
        </button>


        <a href="#" class="navbar-brand">
          <img src="./assets/images/logo.png" alt="">
        </a>

        <!--
          - navbar navigation
        -->

        <nav class="">
          <ul class="navbar-nav">

            <li> <a href="index.php" class="navbar-link">Home</a> </li>
         
            <li> <a href="movies-m.php" class="navbar-link  indicator">MOVIES</a> </li>
                         <li> <a href="web_series.php" class="navbar-link  indicator">Web Series</a> </li>

          </ul>
        </nav>

        <!--
          - search and sign-in
        -->
       <a style="width:1.8em; curser:none;" href="search.php" >
         <img src="includes/search.png"alt=" " />
       </a>
   
      </div>
    </header>



      <section class="movies">



        <!--
          - filter bar
        -->
        
        <!--
          - movies grid
        -->

        <div class="movies-grid">

<?php 
/*
 $runsql = mysqli_query($conn,"SELECT * FROM main_card");  
 

 while( $movie = mysqli_fetch_assoc($runsql)){
 $category = getcategory($conn,$movie['category_id']);
 */
 while($movie=mysqli_fetch_assoc($run_sql)){
?>        

<a href="movie.php?series_no=<?=$movie['series_no']?>">

          <div class="movie-card">

            <div class="card-head">
              <img src="includes/main-card-img/<?=$movie['img']?>" alt="hjk" class="card-img" />

              <div class="card-overlay">

                <div class="bookmark">
                  <ion-icon name="bookmark-outline"></ion-icon>
                </div>

                <div class="rating">
                  <ion-icon name="star-outline"></ion-icon>
                  <span>7.4</span>
                </div>

                <div class="play">
                  <ion-icon name="play-circle-outline"></ion-icon>
                </div>

              </div>
            </div>

            <div class="card-body">
              <h3 class="card-title"><?=$movie['name']?></h>
              <div class="card-info">
                <span class="genre">eng,hin,tam,telg</span>
                <span class="year"><?=   $category?></span></span>
              </div>
        
            </div>

          </div>
          </a>
<?php
}

?>
     </div>

        <!--
          - load more button
        -->
        

      </section>
  
</div>
 
  <!-- Project -->
  <?php



include_once("includes/footer.php");

?>
  <script src="main.js"></script>
    <script src="./assets/js/main.js"></script>



  <!--
    - ionicon link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>
</html>
