<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>Admin:add movie-card</title>
  
  <!-- HTML -->
    <!-- Favicons -->
   <link rel="stylesheet" href="../assets/css/main.css">
  <link rel="stylesheet" href="../assets/css/media_query.css">

  <link href="assets/img/favicon.png" rel="icon">

  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">


  <!-- Custom Styles -->
  <link rel="stylesheet" href="style.css">
</head>

<body>
  <section>
    
       <!-- ======= Header ======= -->
   
      <header class="">



      <div class="navbar">


        <!--
          - menu button for small screen
        -->
        <button class="navbar-menu-btn">
          <span class="one"></span>
          <span class="two"></span>
          <span class="three"></span>
        </button>


        <a href="#" class="navbar-brand">
          <img src="./assets/images/logo.png" alt="">
        </a>

        <!--
          - navbar navigation
        -->

        <nav class="">
          <ul class="navbar-nav">

            <li> <a href="dasbord.php" class="navbar-link">dasbord</a> </li>
            <li> <a href="main_card.php" class="navbar-link">Main_card</a> </li>
            <li> <a href="movies-card.php" class="navbar-link  indicator">add movies</a> </li>
         <li> <a href="web-series.php" class="navbar-link  indicator">add web-series</a> </li>
  <li> <a href="category-add.php" class="navbar-link  indicator">add-category</a> </li>
          </ul>
        </nav>
        <h4 style="text-align: center;">admin</h4>

        <!--
          - search and sign-in
        -->

      
      </div>
    </header>
  
  </section>
 

<section class="home_page" style="margin: 20vh 0">
     <div class="card">

            <div class="card-body">

              <h5 class="card-title">Add movies</h5>

              <!-- General Form Elements -->
              <form action="includes/movies-card.php" method="post" enctype="multipart/form-data">
                <div class="row mb-3">
                  <label for="inputText" class="col-sm-2 col-form-label">Name</label>
                  <div class="col-sm-10">
                    <input name="movie-name" required type="text" class="form-control">
                  </div>
                </div>
              
                </div>
                
                       <div class="row m-2 mb-3">
                  <label class="col-sm-2 col-form-label">series_no</label>
                  <div class="col-sm-10">
                    <select name="series_no" class="form-select" aria-label="Default select example">
                      <option selected>selected the series_no</option>
<?php
include_once('../includes/config.php');
$sql = "SELECT * FROM main_card";
$run = mysqli_query($conn,$sql);
while($data = mysqli_fetch_assoc($run)){
?>
         
                      <option value="<?=$data['series_no']?>"><?=$data['series_no']?></option>
                      
           
<?php
}
?>
                    </div>
                    </select>
                  </div>
                    
              
                <div class="row mb-3">
                  <label for="inputPassword" class="col-sm-2 col-form-label">480p</label>
                  <div class="col-sm-10">
                    <input required name="480p" type="text" class="form-control">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputNumber" class="col-sm-2 col-form-label">720p</label>
                  <div class="col-sm-10">
                    <input required name="720p" type="text" class="form-control">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputNumber" class="col-sm-2 col-form-label">1040p</label>
                  <div class="col-sm-10">
                    <input required name="1040p" type="text" class="form-control">
                  </div>
                </div>
                <div class="row mb-3">
                  <label for="inputNumber" class="col-sm-2 col-form-label">Img</label>
                  <div class="col-sm-10">
                    <input required name="img-banner" class="form-control" type="file" id="formFile" accept="image/*" >
                  </div>
                </div>
                
                
     <div class="row mb-3">

                  
                  <div class="col-sm-5">
                    <input name="submit" type="submit" class="btn btn-primary"></button>
                  </div>
                </div>
                
              


              
            
              </form><!-- End General Form Elements -->

            </div>
          </div>
</section>
  <!-- Project -->
  <script src="main.js"></script>
   <!-- Vendor JS Files -->

  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>

  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.min.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.min.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
    <script src="assets/js/main.js"></script>

  <script src="../assets/js/main.js"></script>

</body>
</html>
