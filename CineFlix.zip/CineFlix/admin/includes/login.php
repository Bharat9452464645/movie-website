<?php
session_start();
$name = $_POST['name'];
$pass = $_POST['pass'];
if(isset($_POST['btn'])){
  if ($name == 'admin' || $pass == '9452464645'){
    $_SESSION['name']=$name;
    $_SESSION['pass']=$pass;
    header('location:../dasbord.php');
    echo $_SESSION['name'];
    if(empty($_SESSION['name'])){
      echo "bjh";
    }
  }
  else{
    header('location:../index.php');
  }

}
?>
                