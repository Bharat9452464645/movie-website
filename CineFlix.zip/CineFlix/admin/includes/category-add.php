
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>HTML</title>
  
  <!-- HTML -->
  
  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="../assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="../assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../assets/vendor/simple-datatables/style.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">


  <!-- Custom Styles -->
  <link rel="stylesheet" href="style.css">
</head>

<body>

  <!-- Project -->


<?php
require("../../includes/config.php");
//include('includes/function.php');

if(isset($_POST['submit'])){
  $name = $_POST['name'];
  
  $banner_img = $_FILES['img-banner']['name'];
//  print_r($_FILES['img-banner']);
  
  $banner_thep = $_FILES['img-banner']['tmp_name'];
  
move_uploaded_file($banner_thep,'../../includes/category-card-img/'.$banner_img);
echo('<div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-1"></i>
               success! Created a new category <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>');

  $sql = "INSERT INTO `category` (`name`,`img`) VALUES ('$name','$banner_img')";
 $rum = mysqli_query($conn,$sql);
  if (!$rum) {
echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-octagon me-1"></i>
                Same thing was wonrg!
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
              </div>';
  }
}
?>
   <!-- Vendor JS Files -->

  <script src="../assets/vendor/apexcharts/apexcharts.min.js"></script>

  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/chart.js/chart.min.js"></script>
  <script src="../assets/vendor/echarts/echarts.min.js"></script>
  <script src="../assets/vendor/quill/quill.min.js"></script>
  <script src="../assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="../assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>
    <script src="../assets/js/main.js"></script>
  <script src="main.js"></script>
</body>
</html>
