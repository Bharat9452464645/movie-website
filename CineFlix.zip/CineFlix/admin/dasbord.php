<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>HTML</title>
  
  <!-- HTML -->
  

  <!-- Custom Styles -->
    <link rel="stylesheet" href="../assets/css/main.css">
  <link rel="stylesheet" href="../assets/css/media_query.css">

  <link rel="stylesheet" href="style.css">
</head>

<body>
      <header class="">



      <div class="navbar">


        <!--
          - menu button for small screen
        -->
        <button class="navbar-menu-btn">
          <span class="one"></span>
          <span class="two"></span>
          <span class="three"></span>
        </button>


        <a href="#" class="navbar-brand">
          <img src="./assets/images/logo.png" alt="">
        </a>

        <!--
          - navbar navigation
        -->

        <nav class="">
          <ul class="navbar-nav">

            <li> <a href="dasbord.php" class="navbar-link">dasbord</a> </li>
            <li> <a href="main_card.php" class="navbar-link">Main_card</a> </li>
            <li> <a href="movies-card.php" class="navbar-link  indicator">add movies</a> </li>
         <li> <a href="web-series.php" class="navbar-link  indicator">add web-series</a> </li>
  <li> <a href="category-add.php" class="navbar-link  indicator">add-category</a> </li>
          </ul>
        </nav>
        <h4 style="text-align: center;">admin</h4>

        <!--
          - search and sign-in
        -->

      
      </div>
    </header>
  
  
  
  <div style="display: flex;
  justify-content: center;
  align-items: center;
  background: black;
  color: white;
  margin-top: 40vh;
  ">
    
<p style="text-align: center;
  font-family: Monospace;
  font-size: 2em;">Wellcome admin-panel</p>
  </div>
  <!-- Project -->
  <script src="main.js"></script>
  
  <script src="../assets/js/main.js"></script>

</body>
</html>
