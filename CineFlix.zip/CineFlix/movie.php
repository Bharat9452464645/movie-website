<?php
include('includes/config.php');
include('includes/function.php');
$series_no = $_GET['series_no'];

/*
foreach($series as $ii){
  echo '<pre>';
  print_r($ii['id']);
  print_r($ii['episode_no']);
}
print_r($series['0']['name']);
*/
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <title>HTML</title>
  
  <!-- HTML -->
  

  <!-- Custom Styles -->
    <link rel="stylesheet" href="./assets/css/main.css">

  <link rel="stylesheet" href="./assets/css/media_query.css">

  <link rel="stylesheet" href="style.css">
<style>

  .movies_list_bh{

  display: flex;

    flex-direction: column;
justify-content: center;
align-items: center;
width: 100vw;

margin: 20vh 0;

}

.movies_list_bh div{
  width: 95vw;
  background: whitesmoke;
  box-shadow: 0 0px 1px #B4B4B4;
  border-radius: 2vh;
    display: flex;
margin-top: 3vhp;
    flex-direction: column;

justify-content: center;
align-items: center;
padding: 5vh 2vw;
}

.movies_list_bh div a{
  background: white;
  width: 80vw;
  box-shadow: 0 0px 0 0px #B4B4B4;
  border-radius: 1vh;
  height: 5vh;

  line-height: 2em;
  text-align: center;
  color: black;
}

.bh{
    display: flex;
    flex-direction: column;
    
    
}
.bh p{
  align-self: flex-start;
  padding: .2em 2em;
  color: black;
  
}

h4{
  color: black;
  margin: 1em;
}
</style>
</head>

<body>

  
    <header class="">



      <div class="navbar">


        <!--
          - menu button for small screen
        -->
        <button class="navbar-menu-btn">
          <span class="one"></span>
          <span class="two"></span>
          <span class="three"></span>
        </button>


        <a href="#" class="navbar-brand">
          <img src="./assets/images/logo.png" alt="">
        </a>

        <!--
          - navbar navigation
        -->

        <nav class="">
          <ul class="navbar-nav">

            <li> <a href="index.php" class="navbar-link">Home</a> </li>
          
            <li> <a href="movies-m.php" class="navbar-link  indicator">MOVIES</a> </li>
                         <li> <a href="web_series.php" class="navbar-link  indicator">Web Series</a> </li>

          </ul>
        </nav>

        <!--
          - search and sign-in
        -->
       <a style="width:1.8em; curser:none;" href="search.php" >
         <img src="includes/search.png"alt=" " />
       </a>
   
      </div>
    </header>


  
<section class="movies_list_bh">
  <div class="vb">
  <div class="bh">
    <?php
    $getseries = getseriesdesc($conn,$series_no);
    $category = getcategory($conn,$getseries['category_id']);
    $aa=$getseries['category_id'];
    ?>
    <h4><?=$getseries['name']?></h4>
    <p>Actors : <?=$getseries['actors']?></p>
    <p>Rate : <?=$getseries['rate']?></p>
    <p>Cate : <?=$category?></p>
    <p>Sesson no : <?=$series_no?></p>
    <p>Type : <?=$getseries['type']?></p>
    <p>Lang : hindi,English,Tamil,Telugo</p>
  
  </div>
<?php
$movies_type = $getseries['type'];
if ($movies_type == 'movies') {
echo '   <h4>movies name</h4>';
$series= getmoviesl($conn,$series_no);
foreach($series as $ii){
?>

   <a href="download.php?id=<?=$ii['id']?>&&480p=<?=$ii['480p']?>&&720p=<?=$ii['720p']?>&&name=<?=$ii['name']?>&&img=<?=$ii['img']?>">
       
   <?php
   echo $ii['name'];
   ?>
   </a> 
 <?php
    }
}

else{
  echo "<h4>episode no</h4>";
  
  $series= getseries($conn,$series_no);
foreach($series as $ii){
  
?>

   <a href="download.php?id=<?=$ii['id']?>&&480p=<?=$ii['480p']?>&&720p=<?=$ii['720p']?>&&name=<?=$ii['name']?>">
   <?php
   echo $ii['episode_no'];
   ?>(<?php
   echo $ii['name'];
   ?>)
   </a> 
 <?php
    }
}
    ?>
  </div>
</section>
  <!-- Project -->
  <?php
  include_once("includes/footer.php");
  ?>
</body>
  
  <script src="./assets/js/main.js"></script>

</html>
