<?php
include_once('includes/config.php');
include_once('includes/function.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="./assets/images/icon.png" type="image/png">
  <title>CineFlix</title>

  <!--
    - custom css link
  -->
  <link rel="stylesheet" href="./assets/css/main.css">
  <link rel="stylesheet" href="./assets/css/media_query.css">

  <!--
    - google font link
  -->
  <link href="https://fonts.googleapis.com/css?family=Inter:100,200,300,regular,500,600,700,800,900" rel="stylesheet" />
</head>

<body>




  <!--
    - main container
  -->
  <div class="container">

  
    <header class="">



      <div class="navbar">


        <!--
          - menu button for small screen
        -->
        <button class="navbar-menu-btn">
          <span class="one"></span>
          <span class="two"></span>
          <span class="three"></span>
        </button>


        <a href="#" class="navbar-brand">
          <img src="./assets/images/logo.png" alt="">
        </a>

        <!--
          - navbar navigation
        -->

        <nav class="">
          <ul class="navbar-nav">

            <li> <a href="#" class="navbar-link">Home</a> </li>
            <li> <a href="#category" class="navbar-link">Category</a> </li>
            <li> <a href="movies-m.php" class="navbar-link  indicator">MOVIES</a> </li>
                         <li> <a href="web_series.php" class="navbar-link  indicator">Web Series</a> </li>

          </ul>
        </nav>

        <!--
          - search and sign-in
        -->
       <a style="width:1.8em; curser:none;" href="search.php" >
         <img src="includes/search.png"alt=" " />
       </a>
   
      </div>
    </header>

<?php
//include_once("includes/header.php");
?>


    <!--
      - MAIN SECTION
    -->
    <main>

      <!--
        - #BANNER SECTION
      -->
    



      <!--
        - #MOVIES SECTION
      -->
      <section class="movies">

        <!--
          - filter bar
        -->
        
        <!--
          - movies grid
        -->

        <div class="movies-grid">

<?php 
 $runsql = mysqli_query($conn,"SELECT * FROM main_card ORDER BY id DESC");  
 

 while( $movie = mysqli_fetch_assoc($runsql)){
 $category = getcategory($conn,$movie['category_id']);
 
?>        

<a href="movie.php?series_no=<?=$movie['series_no']?>">

          <div class="movie-card">

            <div class="card-head">
              <img src="includes/main-card-img/<?=$movie['img']?>" alt="hjk" class="card-img" />

              <div class="card-overlay">

                <div class="bookmark">
                  <ion-icon name="bookmark-outline"></ion-icon>
                </div>

                <div class="rating">
                  <ion-icon name="star-outline"></ion-icon>
                  <span>7.4</span>
                </div>

                <div class="play">
                  <ion-icon name="play-circle-outline"></ion-icon>
                </div>

              </div>
            </div>

            <div class="card-body">
              <h3 class="card-title"><?=$movie['name']?></h>
              <div class="card-info">
                <span class="genre">eng,hin,tam,telg</span>
                <span class="year"><?=   $category?></span></span>
              </div>
        
            </div>

          </div>
          </a>
<?php
}

?>
     </div>

        <!--
          - load more button
        -->
        

      </section>





      <!--
        - #CATEGORY SECTION
      -->
      <section class="category" id="category">

        <h2 class="section-heading">Category</h2>

        <div class="category-grid">
<?php
 $sql2 = "SELECT * FROM category";
 $sql2run = mysqli_query($conn,$sql2);
 
 while($category_name = mysqli_fetch_assoc($sql2run)){
   $name = $category_name['name'];
?>
<a href="category.php?category=<?=$name?>">
         <div class="category-card">

            <img src="includes/category-card-img/<?=$category_name['img']?>" alt="" class="card-img">

            <div class="name"><?=$category_name['name']?></div>
            <div class="total"><?=$num_caregory?></div>
          </div>

</a>
   
<?php
}
?>
        </div>

      </section>





      <!--
        - #LIVE SECTION
      -->
    
    </main>





    <!--
      - FOOTER SECTION
    -->
    <?php

include_once("includes/footer.php");

?>

  </div>





  <!--
    - custom js link
  -->
  <script src="./assets/js/main.js"></script>

  <!--
    - ionicon link
  -->
  <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
  <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
</body>

</html>