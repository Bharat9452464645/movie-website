<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=Edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  *{
    margin:0;
    padding:0;
    
  }
  body{
    display:flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    width:100vw;
    height: 70vh;
    background: whitesmoke;
  }
  h2{
    font-weight: bold;
    font-size: 1.7em;
    font-family: cursive;
  }
  div{
    margin: 3em;
        display:flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: whitesmoke;
    width: 70vw;
    height: 30vh;
    border-radius: .5em;
    box-shadow: 0 0 3px #AEAEAE;
}
  img{
    width: 70vw;
    border-radius: .5em .5em 0 0;
  }
  a{
    margin: .3em;
    background: #515151;
    color: ghostwhite;
    font-family: 'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif;
    line-height: 30px;
    width: 60vw;
    text-align: center;
    border-radius: .6em;
    cursor: none;
    transition: all 2 linear;
  }
  a:hover{
    color: black;
    letter-spacing: 3px;
    background: white;
  }
</style>
 <title>download</title>
  
  <!-- HTML -->
  

  <!-- Custom Styles -->
  <link rel="stylesheet" href="style.css">
</head>

<body>
    <?php
  $_480p = $_GET['480p'];
  $_720p = $_GET['720p'];
  $name = $_GET['name'];

  include_once('includes/config.php');

include_once('includes/function.php');

  
  ?>


<div>
  
  <img src="includes/movies-card-img/<?=$_GET['img']?>"alt="<?=$_GET['ig']?>"></img>
    <h2><?=$name;?></h2>
  <a href="../<?=$_480p?>">480p
</a>
  <a href="../<?=$_720p?>">720p</a>
  </div>
  <!-- Project -->
  <script src="main.js"></script>
</body>
</html>
