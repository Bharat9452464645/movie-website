<?php

function getcategory($conn,$category_id){
  $sql = "SELECT * FROM category where id = $category_id";
  echo mysqli_error($conn);
  $run = mysqli_query($conn,$sql);
  
$data = mysqli_fetch_assoc($run);
  return $data['name'];
}


function getseries($conn,$series_no){
  //money_hist_session_1
  //series_no
  $sql = "SELECT * FROM web_series where series_no = '$series_no'";
  echo mysqli_error($conn);
  $run = mysqli_query($conn,$sql);
 $data = array();
  while($d=mysqli_fetch_assoc($run)){
    $data[]=$d;
  }
  
  return $data;
}
function getmoviesl($conn,$series_no){
  //money_hist_session_1
  //series_no
  $sql = "SELECT * FROM movies_series where series_no = '$series_no'";
  echo mysqli_error($conn);
  $run = mysqli_query($conn,$sql);
 $data = array();
  while($d=mysqli_fetch_assoc($run)){
    $data[]=$d;
  }
  
  return $data;
}



function getseriesdesc($conn,$series_no){
  //8
  //series_no
  $sql = "SELECT * FROM main_card where series_no = '$series_no'";
  echo mysqli_error($conn);
  $run = mysqli_query($conn,$sql);
  $data=mysqli_fetch_assoc($run);
  return $data;
}
/*
  $sql = "SELECT * FROM 'main_card' WHERE category_id == 2";
  $run = mysqli_query($conn,$sql);
  
  $d = mysqli_fetch_assoc($run);
$a= getcategory($conn,$d);
echo $a;
*/



function get_caregory_id($conn,$category_name){
  //money_hist_session_1
  //series_no
  $sql = "SELECT * FROM category WHERE name = '$category_name'";
  
  $run = mysqli_query($conn,$sql);
$d = mysqli_fetch_assoc($run);
$id = $d['id'];

  return $id;
}