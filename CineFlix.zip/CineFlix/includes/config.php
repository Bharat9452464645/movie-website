<?php
$conn = mysqli_connect("0.0.0.0:3306","root","root","movies_app");